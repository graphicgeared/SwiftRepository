//
//  ListCollectionViewCell.swift
//  Instrumental
//
//  Created by Donny Wals on 23/10/2016.
//  Copyright © 2016 DonnyWals. All rights reserved.
//

import UIKit

class ListCollectionViewCell: UICollectionViewCell {
    var delegate: CollectionItemDelegate?
}
