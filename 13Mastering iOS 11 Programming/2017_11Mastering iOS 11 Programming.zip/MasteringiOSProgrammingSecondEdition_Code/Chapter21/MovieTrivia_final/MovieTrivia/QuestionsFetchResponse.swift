//
//  QuestionResponse.swift
//  MovieTrivia
//
//  Created by Donny Wals on 23/08/2017.
//  Copyright © 2017 DonnyWals. All rights reserved.
//

import Foundation

struct QuestionsFetchResponse: Codable {
    let questions: [Question]
}
