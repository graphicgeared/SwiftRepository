import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let url = URL(string: "https://www.google.com")!
let task = URLSession.shared.dataTask(with: url) { data, response, error in
    guard let data = data, error == nil
        else { return }
    
    let responseString = String(data: data, encoding: String.Encoding.utf8)
    //print(responseString)
}

task.resume()

let api_key = "YOUR_API_KEY_HERE"
var urlString = "https://api.themoviedb.org/3/search/movie/"
urlString = urlString.appending("?api_key=\(api_key)")
urlString = urlString.appending("&query=Swift")

let movieURL = URL(string: urlString)!

var urlRequest = URLRequest(url: movieURL)
urlRequest.httpMethod = "GET"
urlRequest.setValue("application/json", forHTTPHeaderField: "Accept")

let movieTask = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
    /**
     * Casting way of doing things
    guard let data = data,
        let json = try? JSONSerialization.jsonObject(with: data, options: [])
        else { return }
    
    guard let jsonDict = json as? [String: AnyObject],
        let resultsArray = jsonDict["results"] as? [[String: AnyObject]]
        else { return }
    
    let firstMovie = resultsArray[0]
    let movieTitle = firstMovie["title"] as! String
    print(movieTitle)
     */
    
    let decoder = JSONDecoder()
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    decoder.dateDecodingStrategy = .custom { decoder in
        let string = decoder
    }
    guard let data = data,
        let movies = try? decoder.decode(MoviesResponse.self, from: data), movies.results.count > 0 else {
            print("did not decode")
            return
    }
    
    print(movies.results[0].title)
}

movieTask.resume()

struct MoviesResponse: Codable {
    let results: [Movie]
}

struct Movie: Codable {
    
    enum CodingKeys: String, CodingKey {
        case id, title, popularity
        case posterPath = "poster_path"
        case date = "release_date"
    }
    
    let id: Int
    let title: String
    let popularity: Float
    let date: Date?
    let posterPath: String?
}
