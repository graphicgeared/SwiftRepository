//
//  AddMovieDelegate.swift
//  FamilyMovies
//
//  Created by Donny Wals on 30/07/16.
//  Copyright © 2016 DonnyWals. All rights reserved.
//

import Foundation

protocol AddMovieDelegate {
    func saveMovie(withName name: String)
}
