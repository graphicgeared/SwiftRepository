//
//  DataParser.swift
//  clairvoyant
//
//  Created by 万畅 on 15/11/24.
//  Copyright © 2015年 Luminagic. All rights reserved.
//

import Foundation

class DataParser {
    

}