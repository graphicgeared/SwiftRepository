import UIKit


class UserHistoryViewController: UIViewController ,PNChartDelegate {

    var userName: String? = ""
    var patient: Patient?

    @IBOutlet weak var lblUserName: UILabel!

    override func viewDidLoad() {
        // Do any additional setup after loading the view, typically from a nib.
        if userName != "" {
            lblUserName.text = userName
        }
        let lineChart: PNLineChart = PNLineChart(frame: CGRectMake(0, 195.0, 320, 200.0))
        lineChart.yLabelFormat = "%1.1f"
        lineChart.showLabel = true
        lineChart.backgroundColor = UIColor.clearColor()

        var time01Array: [String] = []
        let formatter: NSDateFormatter = NSDateFormatter()
        formatter.dateFormat = "MM-dd"
        for i in 0..<7 {
            let lastweek = NSDate().dateByAddingTimeInterval(-86400.0*Double(6 - i))
            let dateTimePrefix: String = formatter.stringFromDate(lastweek)
            print(dateTimePrefix)
            time01Array.append(dateTimePrefix)
        }

        lineChart.xLabels = time01Array

        lineChart.showCoordinateAxis = true
        lineChart.delegate = self
        // Line Chart Nr.1 I will use test data if not have one weak 's data
        var data01Array: [NSNumber] = [60.1, 160.1, 126.4, 262.2, 186.2, 127.2, 176.2]
        let mysights = patient!.sights!
        print(mysights.count)
        if mysights.count >= 7 {
            data01Array = []
            for i in (mysights.count - 7)..<mysights.count {
                if let temp = mysights[i] as? Sight {
                    data01Array.append(temp.finalscore!)
                }
            }
        }
        let data01: PNLineChartData = PNLineChartData()
        data01.color = UIColor.redColor()
        data01.itemCount = UInt(data01Array.count)
        data01.inflexionPointStyle = PNLineChartPointStyle.Circle

        data01.getData = ({(index: UInt) -> PNLineChartDataItem in
            //            var yValue: CGFloat = data01Array[index]
            let yValue: CGFloat = CGFloat(data01Array[Int(index)])
            let item = PNLineChartDataItem(y: yValue)
            return item
        })

        lineChart.chartData = [data01]
        lineChart.strokeChart()
        //        lineChart.delegate = self
        self.view.addSubview(lineChart)

    }

    func userClickedOnLineKeyPoint(point: CGPoint, lineIndex: Int, pointIndex: Int) {
        print("Click Key on line \(point.x)," +
            "\(point.y) line index is \(lineIndex) and point index is \(pointIndex)")
    }

    func userClickedOnLinePoint(point: CGPoint, lineIndex: Int) {
        print("Click Key on line \(point.x), \(point.y) line index is \(lineIndex)")
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
