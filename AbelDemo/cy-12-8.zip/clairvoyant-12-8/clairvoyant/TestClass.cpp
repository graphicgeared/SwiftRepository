//
//  TestClass.cpp
//  clairvoyant
//
//  Created by 万畅 on 15/11/28.
//  Copyright © 2015年 Luminagic. All rights reserved.
//

#include <stdio.h>

#include <iostream>
#include <fcntl.h>
#include <fstream>
#include <google/protobuf/text_format.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>

#include "measurement.pb.h"
using namespace std;

class TestClass {




// Iterates though all people in the AddressBook and prints info about them.
int myprint(char* argv[]) {
    // Verify that the version of the library that we linked against is
    // compatible with the version of the headers we compiled against.
    GOOGLE_PROTOBUF_VERIFY_VERSION;



    Measurement measure2;

    {
//        measure.set_side_a("true");
//        measure.set_side_b("false");
//        measure.set_image("4000400014002");

//        Measurement *measure1 = new Measurement(); //My protobuf object
//
//        bool retValue = false;
//
//        int fileDescriptor = open(argv[0], O_RDONLY);
//
//        if( fileDescriptor < 0 )
//        {
//            std::cerr << " Error opening the file " << std::endl;
//            return false;
//        }
//
//        google::protobuf::io::FileInputStream fileInput(fileDescriptor);
//        fileInput.SetCloseOnDelete( true );
//
//        if (!google::protobuf::TextFormat::Parse(&fileInput, measure1))
//        {
//            cerr << std::endl << "Failed to parse file!" << endl;
//            return -1;
//        }
//        else
//        {
//            retValue = true;
//            cerr << "Read Input File - " << argv[1] << endl;
//        }
        //------
        const unsigned char bytes[199] = {10, 192, 1, 208, 23, 125, 210, 55, 125, 212, 87, 125, 214, 119, 125, 216, 151, 125, 218, 183, 125, 220, 215, 125, 222, 247, 125, 224, 23, 126, 226, 55, 126, 228, 87, 126, 230, 119, 126, 232, 151, 126, 234, 183, 126, 236, 215, 126, 238, 247, 126, 240, 23, 127, 242, 55, 127, 244, 87, 127, 246, 119, 127, 248, 151, 127, 250, 183, 127, 252, 215, 127, 254, 247, 127, 0, 24, 128, 2, 56, 128, 4, 88, 128, 6, 120, 128, 8, 152, 128, 10, 184, 128, 12, 216, 128, 14, 248, 128, 16, 24, 129, 18, 56, 129, 20, 88, 129, 22, 120, 129, 24, 152, 129, 26, 184, 129, 28, 216, 129, 30, 248, 129, 32, 24, 130, 34, 56, 130, 36, 88, 130, 38, 120, 130, 40, 152, 130, 42, 184, 130, 44, 216, 130, 46, 248, 130, 48, 24, 131, 50, 56, 131, 52, 88, 131, 54, 120, 131, 56, 152, 131, 58, 184, 131, 60, 216, 131, 62, 248, 131, 64, 24, 132, 66, 56, 132, 68, 88, 132, 70, 120, 132, 72, 152, 132, 74, 184, 132, 76, 216, 132, 78, 248, 132, 16, 1, 24, 0};

        char * dir = getcwd(NULL, 0); // Platform-dependent, see reference link below
        printf("Current dir: %s", dir);
        // Read the existing address book.
        //fstream input(argv[0], ios::in | ios::binary);
        //streambuf* sb;
        filebuf fb;
        fb.open(argv[0], ios::in | ios::binary);
        //char* temp;
        //temp = (char*)bytes;
//        sb->sputn(temp, sizeof(bytes)-1);
//        istream input(&fb);
        char* contents;
        contents = new char [199];
        fb.sgetn(contents, 199);


//        istream input(
//        char test[199] = {0};
//        input.get(test, 199);
        string str(contents);
//        int i;
//        for(i = 0; i < 199; i++)
//        {
//            str += bytes[i];
//        }
//        printf("%s\n",str.data());
        ifstream ifs(argv[0]);
        string content( (std::istreambuf_iterator<char>(ifs) ),
                            (std::istreambuf_iterator<char>()    ) );
        printf("%s\n",content.data());

        measure2.ParseFromString(content);
        cout << measure2.side_a() << measure2.side_b() << measure2.image() << endl;

//        if (!input) {
//            cout << argv[1] << ": File not found.  Creating a new file." << endl;
//        } else if (!measure2.ParseFromIstream(&input)) {
//            cerr << "Failed to parse address book." << endl;
//            return -1;
//        }

//        cout << argv[0] << endl;
//        if (!measure2.ParseFromIstream(&input)) {
//            cerr << "Failed to parse address book." << endl;
//            return -1;
//        }
        return 0;
    }
}
public:
int testInput() {
    char* argv[] = {"1","2"};
    argv[0]= "/Users/wanchang/testfile";
    myprint(argv);
    return 0;
}

};