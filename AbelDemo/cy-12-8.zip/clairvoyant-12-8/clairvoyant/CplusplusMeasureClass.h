#import <UIKit/UIKit.h>

@interface CplusplusMeasureClass : NSObject

-(NSString*) dosomething;

@end
