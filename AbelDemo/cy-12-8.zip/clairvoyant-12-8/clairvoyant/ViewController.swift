import UIKit
import CoreData
import Foundation


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    private var userCell = "userCell"
//    var managedContext: NSManagedObjectContext!
    var patients = [Patient]()

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        CoreDataStack.sharedInstance.loadPatientData()
        patients = CoreDataStack.sharedInstance.patients
        tableView.registerClass(UITableViewCell.self,
            forCellReuseIdentifier: "Cell")

        let instanceOfCustomObject: CplusplusMeasureClass = CplusplusMeasureClass()
        instanceOfCustomObject.dosomething()

        }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(tableView: UITableView,
        numberOfRowsInSection section: Int) -> Int {
            return patients.count;
    }


    func tableView(tableView: UITableView,
        cellForRowAtIndexPath
        indexPath: NSIndexPath) -> UITableViewCell {
            //            tableView.separatorStyle = UITableViewCellSeparatorStyle.SingleLine
            let cell =
                tableView.dequeueReusableCellWithIdentifier(userCell,
                    forIndexPath: indexPath)
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateStyle = .ShortStyle
            dateFormatter.timeStyle = .MediumStyle
            let user = patients[indexPath.row]
            cell.textLabel!.text = user.name
            return cell
    }

    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    func tableView(tableView: UITableView,
        commitEditingStyle editingStyle: UITableViewCellEditingStyle,
        forRowAtIndexPath indexPath: NSIndexPath) {

        if editingStyle == UITableViewCellEditingStyle.Delete {

            let userToRemove =  patients[indexPath.row]
            CoreDataStack.sharedInstance.context.deleteObject(userToRemove)
            CoreDataStack.sharedInstance.saveContext()
            patients.removeAtIndex(indexPath.row)

            tableView.deleteRowsAtIndexPaths([indexPath],
                withRowAnimation: UITableViewRowAnimation.Automatic)

            self.tableView.reloadData()
        }
    }


    @IBAction func AddUser(sender: AnyObject) {
        var nameTextField: UITextField?
        var ageTextField: UITextField?
        let alert = UIAlertController(title: "Add New User",
            message: "请填写姓名和出生日期（例如: 1986-01-01)",
            preferredStyle: .Alert)
        let saveAction = UIAlertAction(title: "Save", style: .Default) {
            (action: UIAlertAction!) -> Void in
                print("show= \(alert.textFields![0]) # \(alert.textFields![1])")
                let name = alert.textFields![0].text!
                let dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let birthday = dateFormatter.dateFromString(alert.textFields![1].text!)
                self.saveUser(name,birthday: birthday!)
                self.tableView.reloadData()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .Default) {
            (action: UIAlertAction!) -> Void in
        }
        alert.addTextFieldWithConfigurationHandler { (textField) -> Void in
            // Enter the textfiled customization code here.
            nameTextField = textField
            nameTextField?.placeholder = "Name"
        }
        alert.addTextFieldWithConfigurationHandler { (textField) -> Void in
            // Enter the textfiled customization code here.
            ageTextField = textField
            ageTextField?.placeholder = "Birthday"
            //                ageTextField?.secureTextEntry = true
        }
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        presentViewController(alert, animated: true,
            completion: nil)
    }


    func saveUser(name: String, birthday: NSDate) {
        let entity = NSEntityDescription.entityForName("Patient",
            inManagedObjectContext: CoreDataStack.sharedInstance.context)
        let user = NSManagedObject(entity: entity!,
            insertIntoManagedObjectContext: CoreDataStack.sharedInstance.context)
        user.setValue(name, forKey: "name")
        user.setValue(birthday, forKey: "birthday")
        do {
            try CoreDataStack.sharedInstance.context.save()
            patients.append(user as! Patient)
            CoreDataStack.sharedInstance.loadPatientData()


        } catch let unknownError {
            print("save user error \(unknownError) is an unknown error.")
        }
    }


    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView : UIView
        footerView = UIView(frame: CGRectMake(0, 0, tableView.frame.size.width, 170))
        footerView.backgroundColor = UIColor.whiteColor()
        let topBorder: UIView
        topBorder = UIView(frame: CGRectMake(0, 0, footerView.frame.size.width, 1))
        topBorder.backgroundColor = UIColor.init(red: 224/255.0,
            green: 224/255.0, blue: 224/255.0, alpha: 1.0)
        footerView.addSubview(topBorder)


        let gotoMeasureButton = UIButton(type: UIButtonType.System)
        gotoMeasureButton.backgroundColor = UIColor.greenColor()
        gotoMeasureButton.layer.cornerRadius = 5
        gotoMeasureButton.layer.borderWidth = 1
        gotoMeasureButton.layer.borderColor = UIColor.greenColor().CGColor
        gotoMeasureButton.setTitle("测量", forState: UIControlState.Normal)

        let middleLen = (tableView.frame.width - 100)/2
        gotoMeasureButton.frame = CGRectMake(middleLen, 50, 100, 50)

        gotoMeasureButton.addTarget(self,
            action: "buttonTouched:", forControlEvents: UIControlEvents.TouchUpInside)

        footerView.addSubview(gotoMeasureButton)

        return footerView
    }

    func buttonTouched(sender: UIButton!) {
        self.performSegueWithIdentifier("goto_measure", sender: self)
    }

    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 170.0
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.

        if segue.identifier == "Details" {
            let indexPath = tableView.indexPathForCell(sender as! UITableViewCell)!
            let userHistoryVC = segue.destinationViewController as! UserHistoryViewController
            let userName = patients[indexPath.row].name
            userHistoryVC.userName = userName
            userHistoryVC.patient = patients[indexPath.row]
        }else if segue.identifier == "goto_measure" {
//            let measureVC = segue.destinationViewController as! MeasureSightViewController
//            measureVC.patients = CoreDataStack.sharedInstance.patients
//            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//            measureVC.managedContext = appDelegate.coreDataStack.context
        }


    }

}
