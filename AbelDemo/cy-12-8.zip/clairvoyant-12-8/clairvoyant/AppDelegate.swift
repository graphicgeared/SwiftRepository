import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {

            let flag: Bool = UIApplication.instancesRespondToSelector(
                Selector("registerUserNotificationSettings:"))
            if flag {

                UIApplication.sharedApplication().registerUserNotificationSettings(
                    UIUserNotificationSettings(forTypes: [UIUserNotificationType.Alert,
                        UIUserNotificationType.Badge], categories: nil))
            }

            return true
    }


    func applicationDidEnterBackground(application: UIApplication) {
        CoreDataStack.sharedInstance.saveContext()
    }

    func applicationWillTerminate(application: UIApplication) {
        CoreDataStack.sharedInstance.saveContext()
    }

    func applicationWillEnterForeground(application: UIApplication) {
        print("in applicationWillEnterForeground")
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
    }

}
