import UIKit
import Foundation
import CoreBluetooth
import CoreData


class MeasureSightViewController: UIViewController, CBPeripheralDelegate,
    CBCentralManagerDelegate, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var showEye: UILabel!
    @IBOutlet weak var saveDataButton: UIButton!
    @IBOutlet weak var chosenLabel: UILabel!
    @IBOutlet weak var userPicker: UIPickerView!

    var myAlldata = NSMutableData()
//    var dataStr = ""
    var peripheral: CBPeripheral!

    var manager: CBCentralManager!
    var isBluetoothEnabled = false
    var visiblePeripheralUUIDs = NSMutableOrderedSet()
    var visiblePeripherals = [String: Peripheral]()
    var scanTimer: NSTimer?
    var connectionAttemptTimer: NSTimer?
    var connectedPeripheral: CBPeripheral?
    var pocessedResult: Float = 0
    let leftrightTest: Int = random() % 2
    var currentPatient: Patient!
    var curentRaw: String = ""
    var chosenPatientIndex = 0

    @IBAction func saveDatatoPatient(sender: AnyObject) {
        let sightEntity = NSEntityDescription.entityForName("Sight",
            inManagedObjectContext: CoreDataStack.sharedInstance.context)
        let sight = Sight(entity: sightEntity!,
            insertIntoManagedObjectContext: CoreDataStack.sharedInstance.context)
        sight.date = NSDate()
        sight.finalscore = pocessedResult
        sight.whicheye = leftrightTest
        sight.raw = curentRaw

        let sights = CoreDataStack.sharedInstance.patients[chosenPatientIndex].sights?.mutableCopy()
            as? NSMutableOrderedSet
        sights!.addObject(sight)
        if let mysights = sights!.copy() as? NSOrderedSet {
            CoreDataStack.sharedInstance.patients[chosenPatientIndex].sights = mysights
        }

        CoreDataStack.sharedInstance.saveContext()
        saveDataButton.setTitle("保存成功！", forState: .Normal)



    }

    override func viewDidLoad() {
        super.viewDidLoad()
        print("in Measue")

        userPicker.dataSource = self
        userPicker.delegate = self
        // set the default value for picker
        if CoreDataStack.sharedInstance.patients.count > 0 {
            userPicker.selectRow(0, inComponent: 0, animated: true)
            currentPatient = CoreDataStack.sharedInstance.patients[0]
            chosenLabel.text = "你选择了：" + CoreDataStack.sharedInstance.patients[0].name!
            saveDataButton.hidden = true
        }


    }

    override func viewDidAppear(animated: Bool) {

    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        manager = CBCentralManager(delegate: self, queue: nil,
            options: [CBCentralManagerOptionShowPowerAlertKey: true])
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)

        manager = CBCentralManager(delegate: self, queue: nil,
            options: [CBCentralManagerOptionShowPowerAlertKey: true])
    }


    func centralManager(central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral,
        error: NSError?) {
        manager.connectPeripheral(peripheral, options: nil)
    }


    func centralManagerDidUpdateState(central: CBCentralManager) {
        var printString: String
        switch central.state {
        case .PoweredOff:
            printString = "Bluetooth hardware powered off."
            isBluetoothEnabled = false
        case .PoweredOn:
            printString = "Bluetooth hardware powered on."
            isBluetoothEnabled = true
            startScanning()
        case .Resetting:
            printString = "Bluetooth hardware is resetting."
            isBluetoothEnabled = false
        case .Unauthorized:
            printString = "Bluetooth hardware is unauthorized."
            isBluetoothEnabled = false
        case .Unsupported:
            printString = "Bluetooth hardware is unsupported."
            isBluetoothEnabled = false
        case .Unknown:
            printString = "Bluetooth hardware state is unknown."
            isBluetoothEnabled = false
        }
        print("State updated to: \(printString)")
    }



    func startScanning() {
        print("Started scanning.")
        visiblePeripheralUUIDs.removeAllObjects()
        visiblePeripherals.removeAll(keepCapacity: true)
//        manager.scanForPeripheralsWithServices([CBUUID(string: "FFF6")], options: nil)
//        manager.scanForPeripheralsWithServices(nil, options: nil)
        manager.scanForPeripheralsWithServices([CBUUID(string: "FFE0")], options: nil)

//        scanTimer = NSTimer.scheduledTimerWithTimeInterval(10, target: self,
//            selector: Selector("stopScanning"), userInfo: nil, repeats: true)
    }

    func stopScanning() {
        print("Stopped Scanning")
        print("Found \(visiblePeripherals.count) peripherals.")
        manager.stopScan()
        scanTimer?.invalidate()
    }

    func centralManager(central: CBCentralManager, didConnectPeripheral peripheral: CBPeripheral) {
        print("##Peripheral connected: \(peripheral.name ?? peripheral.identifier.UUIDString)")
        connectionAttemptTimer?.invalidate()
        self.peripheral = peripheral

        peripheral.delegate = self
        peripheral.readRSSI()
        peripheral.discoverServices(nil)
        print("###########连接")
        let localNotification = UILocalNotification()
        localNotification.fireDate = NSDate(timeIntervalSinceNow: 5)
        localNotification.alertBody = "Abel alertbody"
        localNotification.timeZone = NSTimeZone.defaultTimeZone()
        localNotification.applicationIconBadgeNumber =
            UIApplication.sharedApplication().applicationIconBadgeNumber + 1

        UIApplication.sharedApplication().scheduleLocalNotification(localNotification)
    }

    func centralManager(central: CBCentralManager,
        didDiscoverPeripheral peripheral: CBPeripheral,
        advertisementData: [String : AnyObject], RSSI: NSNumber) {

            print("Peripheral found with name: \(peripheral.name)\n" +
                "UUID: \(peripheral.identifier.UUIDString)\n" +
                "RSSI: \(RSSI)\nAdvertisement Data: \(advertisementData)")
            visiblePeripheralUUIDs.addObject(peripheral.identifier.UUIDString)
            visiblePeripherals[peripheral.identifier.UUIDString] =
                Peripheral(peripheral: peripheral,
                rssi: RSSI.stringValue, advertisementDictionary: advertisementData)
            //CC41-A
            if peripheral.name == "CC41-A" {
                print("In here \(peripheral)")
                connectionAttemptTimer =
                    NSTimer.scheduledTimerWithTimeInterval(10,
                        target: self, selector: Selector("timeoutPeripheralConnectionAttempt"),
                        userInfo: nil, repeats: false)
                manager.connectPeripheral(peripheral, options: nil)
            }
    }

    func timeoutPeripheralConnectionAttempt() {
        print("Peripheral connection attempt timed out.")
        if connectedPeripheral != nil {
            manager.cancelPeripheralConnection(connectedPeripheral!)
        }
        connectionAttemptTimer?.invalidate()
    }

    func peripheral(peripheral: CBPeripheral, didDiscoverServices error: NSError?) {
        if let error = error {
            print(error)
        }
        else {
            print("\(peripheral.services)")
        }

        print("Did discover services.")
        print("## find service= \(peripheral.services?.count) # \(peripheral.services)")
        for service in peripheral.services! {
            if service.UUID.description == "FFE0" {
                peripheral.discoverCharacteristics(nil, forService: (service as CBService))
            }
        }
    }

    func centralManager(central: CBCentralManager
        , didFailToConnectPeripheral peripheral: CBPeripheral, error: NSError?) {
        print("didFailToConnectPeripheral")
    }

    func peripheral(peripheral: CBPeripheral,
        didDiscoverCharacteristicsForService service: CBService, error: NSError?) {

            let characteristic = service.characteristics![0] as CBCharacteristic
            print("Measue# \(characteristic)")
            peripheral.readValueForCharacteristic(characteristic)
            peripheral.setNotifyValue(true, forCharacteristic: characteristic)
    }

    

    // you want to recieve updates for a characteristic, like say, the battery for a FitBit Flex.
    func peripheral(peripheral: CBPeripheral,
        didUpdateValueForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
            NSLog("###1# %@ ###1#", characteristic.value!);
            if let error = error {
                print("Failed to updated value for characteristic with error: \(error)")
            } else {
                let data = characteristic.value!
                var values = [UInt8](count:data.length, repeatedValue:0)
                data.getBytes(&values, length:data.length)
//                print("data=",data)
                myAlldata.appendData(data)

                let ptr = UnsafePointer<UInt8>(myAlldata.bytes)
                let bytes = UnsafeBufferPointer<UInt8>(start: ptr, count: myAlldata.length)
                if(bytes.contains(UInt8(0x80)) && bytes.contains(UInt8(0x81)) ) {
                    for i in bytes {
                        print("i=",i)
                    }
                    print("bytes",bytes.count,bytes[21],bytes[22],"mydata=",myAlldata)

                    var start = bytes.indexOf(UInt8(0x80)), end = bytes.indexOf(UInt8(0x81))
                    print(bytes[start!],bytes[end!])
                    let slice = Array(bytes[start!+1..<end!])
                    print("slice=",slice,"length=",slice.count)
                    // deal with data length info
                    print(slice[0],slice[1])
                    var str1 = String(slice[0], radix : 2)
                    var str2 = String(slice[1], radix : 2)
                    str1 = str1.pad(8)
                    str2 = str2.pad(8)
                    var newstr = "00"
                    print("#1",str1.substringFromIndex(str1.startIndex.advancedBy(1)))
                    print("#2",str2.substringFromIndex(str2.startIndex.advancedBy(1)))
                    print(str1, str2)
                    newstr = newstr + str2.substringFromIndex(str2.startIndex.advancedBy(1))
                    newstr = newstr + str1.substringFromIndex(str1.startIndex.advancedBy(1))
                    print(newstr.pad(16))
                    var length = Int(strtoul(newstr.pad(16),nil,2))
                    print("length=", length,"(length % 7 )",(length % 7 ))
                    // get additional binary
                    let splitIndex :Int =  length + (2) + (7 - length % 7 )
                    print("@",slice[2], slice[splitIndex], slice[splitIndex+1], slice[splitIndex+2])
                    var addtionalstr = ""
                    for var i = Int(splitIndex); i < slice.count; i++ {
                        var tempstr = String(slice[i], radix : 2).pad(8)
                        var index1 = tempstr.startIndex.advancedBy(1)
                        addtionalstr += tempstr.pad(8).substringFromIndex(index1)
                    }
                    print(addtionalstr)
                    var finalStr = ""
                    var numbers: [Int] = []
                    for var j = 2; j < length+2; j++ {
//                        print(slice[j])
                        var tempstr =  String(slice[j], radix : 2).pad(8)
                        var index1 = tempstr.startIndex.advancedBy(1)
                        print(tempstr.substringFromIndex(index1),addtionalstr[j-2],"#j=",j)
                        finalStr = finalStr + tempstr.substringFromIndex(index1) + addtionalstr[j-2]
                        var newstr = tempstr.substringFromIndex(index1) + addtionalstr[j-2]
                        let num = Int(strtoul(newstr.pad(8),nil,2))
                        print("num=",num)
                        numbers.append(num)

                    }
                    print(numbers)
                    print(finalStr)
                    let data = NSData(bytes: finalStr, length: sizeof(String))
                    myAlldata.setData(NSData())
                }
            }
    }

    func peripheral(peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: NSError?) {
        print("Did update RSSI.")
        if let error = error {
            print("Error getting RSSI: \(error)")
        } else {
            print("rssi = \(RSSI)")
        }
    }
    //handle picker logic
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CoreDataStack.sharedInstance.patients.count
    }

    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int)
        -> String? {
        return CoreDataStack.sharedInstance.patients[row].name
    }

    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        chosenLabel.text = "你选择了：" + CoreDataStack.sharedInstance.patients[row].name!
        currentPatient =  CoreDataStack.sharedInstance.patients[row]
        chosenPatientIndex = row

    }



}
