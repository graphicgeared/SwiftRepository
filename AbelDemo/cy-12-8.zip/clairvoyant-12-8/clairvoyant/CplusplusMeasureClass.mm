#include "measurement.pb.h"
#import "CplusplusMeasureClass.h"
#import "TestClass.cpp"
#include <fstream>

using namespace std;

@implementation CplusplusMeasureClass

//#if TARGET_RT_BIG_ENDIAN
//const NSStringEncoding kEncoding_wchar_t = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF32BE);
//#else
//const NSStringEncoding kEncoding_wchar_t = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF32LE);
//#endif

void test(){

}

-(NSString*) dosomething {
    
//    TestClass *t = new TestClass();
//    t->testInput();


    NSString * result = @"";

//    Measurement *measure = [[Measurement builder]];
//    Measurement *measure = new Measurement();
//    measure->set_side_a("true");
//    measure->set_side_a("false");
//    measure->set_image("20002001");
//    std::string ps =  measure->SerializeAsString();
//    NSData *testData = [NSData dataWithBytes:ps.c_str() length:ps.size()];
//    char raw1[[testData length]];
    Measurement *measure1 =new Measurement();
//    [testData getBytes:raw1 length:[testData length]];
//    meausre1->ParseFromArray(raw1, [testData length]);

//    measure.set_side_a("true");
//    measure.set_side_b("true");

//    std::string  bits = "00001010110000000000000111010000000101110111110111010010001101110111110111010100010101110111110111010110011101110111110111011000100101110111110111011010101101110111110111011100110101110111110111011110111101110111110111100000000101110111111011100010001101110111111011100100010101110111111011100110011101110111111011101000100101110111111011101010101101110111111011101100110101110111111011101110111101110111111011110000000101110111111111110010001101110111111111110100010101110111111111110110011101110111111111111000100101110111111111111010101101110111111111111100110101110111111111111110111101110111111100000000000110001000000000000010001110001000000000000100010110001000000000000110011110001000000000001000100110001000000000001010101110001000000000001100110110001000000000001110111110001000000000010000000110001000000100010010001110001000000100010100010110001000000100010110011110001000000100011000100110001000000100011010101110001000000100011100110110001000000100011110111110001000000100100000000110001000001000100010001110001000001000100100010110001000001000100110011110001000001000101000100110001000001000101010101110001000001000101100110110001000001000101110111110001000001000110000000110001000001100110010001110001000001100110100010110001000001100110110011110001000001100111000100110001000001100111010101110001000001100111100110110001000001100111110111110001000001101000000000110001000010001000010001110001000010001000100010110001000010001000110011110001000010001001000100110001000010001001010101110001000010001001100110110001000010001001110111110001000010000010000000000010001100000000000";

    Byte *byteArray = (Byte[]){10, 192, 1, 208, 23, 125, 210, 55, 125, 212, 87, 125, 214, 119, 125, 216, 151, 125, 218, 183, 125, 220, 215, 125, 222, 247, 125, 224, 23, 126, 226, 55, 126, 228, 87, 126, 230, 119, 126, 232, 151, 126, 234, 183, 126, 236, 215, 126, 238, 247, 126, 240, 23, 127, 242, 55, 127, 244, 87, 127, 246, 119, 127, 248, 151, 127, 250, 183, 127, 252, 215, 127, 254, 247, 127, 0, 24, 128, 2, 56, 128, 4, 88, 128, 6, 120, 128, 8, 152, 128, 10, 184, 128, 12, 216, 128, 14, 248, 128, 16, 24, 129, 18, 56, 129, 20, 88, 129, 22, 120, 129, 24, 152, 129, 26, 184, 129, 28, 216, 129, 30, 248, 129, 32, 24, 130, 34, 56, 130, 36, 88, 130, 38, 120, 130, 40, 152, 130, 42, 184, 130, 44, 216, 130, 46, 248, 130, 48, 24, 131, 50, 56, 131, 52, 88, 131, 54, 120, 131, 56, 152, 131, 58, 184, 131, 60, 216, 131, 62, 248, 131, 64, 24, 132, 66, 56, 132, 68, 88, 132, 70, 120, 132, 72, 152, 132, 74, 184, 132, 76, 216, 132, 78, 248, 132, 16, 1, 24, 0};



    NSMutableData *buffer = [NSMutableData data];
    [buffer appendBytes:byteArray length:199*sizeof(Byte)];

    int len1 = [buffer length];
    NSLog(@"%d",len1);
    char raw1[len1];
    [buffer getBytes:raw1 length:len1];
    measure1->ParseFromArray(raw1, 199);
    bool mybool = measure1->has_image();


    char* data1 = (char*)measure1->image().data();
//    unsigned size = measure1->image().size() * sizeof(wchar_t);

//    NSString* result11 = [[NSString alloc] initWithBytes:data1 length:size encoding:kEncoding_wchar_t];
     int t = measure1->image().size();

//    NSData *dataA = [NSData dataWithBytes: data1   length:strlen(data1)];
    NSData *dataA = [NSData dataWithBytes: data1   length:192];
//    let ptr = UnsafePointer<UInt8>(dataA.bytes)
//    let bytes = UnsafeBufferPointer<UInt8>(start: ptr, count: myAlldata.length)

//    NSString* result1 = [NSString stringWithUTF8String:measure->side_a().c_str()];
//    NSString* result2 = [NSString stringWithUTF8String:measure->side_b().c_str()];


    //    measure->ParseFromString(str3);


//    int len = [buffer length];
//    NSLog(@"%d",len);
//    char raw[len];
//    [buffer getBytes:raw length:len];
//    measure->ParseFromArray(raw, len);

//    int bitsLength = bits.length;
//    NSLog(@"length=%d %d",bitsLength, bitsLength/8);
//    for (int i = 0; i < bitsLength; i += 8) {
//        char byte = 0;
//        for (int bit = 0; bit < 8 && i + bit < bitsLength; bit++) {
//
//            char mychar = [bits characterAtIndex:i + bit];
////            NSLog(@"mychar %d", mychar == '0');
//            if(mychar != '0') {
//                byte += (1 << bit);
//            }
//        }
//        [buffer appendBytes:&byte length:1];
//
//        NSLog(@"byte %d,#", (int)byte);
//    }

//    NSData* data = [NSData dataWithBytes:bytes length:sizeof(bytes)];
//    int len = [buffer length];
//    NSLog(@"%d",len);
//    char raw[len];
//    [buffer getBytes:raw length:len];
//    measure.ParseFromArray(raw, len);
//    measure->ParseFromArray(raw, len);
//    measure->ParseFromArray(raw, [buffer length]);

//    char raw[[buffer length]];

//    [buffer getBytes:raw length:[buffer length]];
//    measure->ParseFromArray(raw, 199*sizeof(Byte));

//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentDirectory = [paths objectAtIndex:0];
////
//    NSString *filename = [NSString stringWithFormat:@"%@/addressbook.dat", documentDirectory];

//    Measurement measure1;
//    measure1.set_side_a("true");
//    measure1.set_side_a("false");
//    measure1.set_image("200020012002");

//    int len = [buffer length];
//    NSLog(@"%d",len);
//    char raw[len];
//    [buffer getBytes:raw length:len];
//    measure1.ParseFromArray(raw, len);



//    fstream out([filename UTF8String], ios::out | ios::binary | ios::trunc);
//    measure1.SerializeToOstream(&out);
//    out.close();
//    NSError *error = nil;
//    NSData *newData = [NSData dataWithContentsOfFile:filename];
//
//    [buffer writeToFile: filename atomically:YES];

    Measurement measure2;

//    NSString* result11 = [NSString stringWithUTF8String:measure2.side_a().c_str()];
// 
//
//
//
//    NSString* result1 = [NSString stringWithUTF8String:measure->side_a().c_str()];
//    NSString* result2 = [NSString stringWithUTF8String:measure->side_b().c_str()];
//    NSString* result11 = [NSString stringWithUTF8String:measure->image().c_str()];
    return result;
}



@end
