import Foundation
import CoreData

extension Sight {

    @NSManaged var date: NSDate?
    @NSManaged var finalscore: NSNumber?
    @NSManaged var raw: String?
    @NSManaged var scene: NSNumber?
    @NSManaged var whicheye: NSNumber?
    @NSManaged var patient: Patient?

}
