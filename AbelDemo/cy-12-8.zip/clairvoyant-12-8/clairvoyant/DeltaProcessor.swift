import Foundation

extension String {
    struct NumberFormatter {
        static let instance = NSNumberFormatter()
    }
    var doubleValue: Double? {
        return NumberFormatter.instance.numberFromString(self)?.doubleValue
    }
    var integerValue: Int? {
        return NumberFormatter.instance.numberFromString(self)?.integerValue
    }

    func pad(length: Int) -> String {
        let diff = length - self.characters.count
        if diff > 0 {
            var padded = self
            for _ in 0..<diff {
                padded = "0" + padded
            }
            return padded
        } else {
            return self
        }
    }

//    subscript (i: Int) -> Character {
//        return self[self.startIndex.advancedBy(i)]
//    }

    subscript (i: Int) -> String {
        return String(self[self.startIndex.advancedBy(i)] as Character)
    }
}

class DeltaProcessor {

    func ciculateDelta(primitivenumber: [String]) -> Float {
        print("ciculateDelta")

//        var results: Array<Float> = [0, 0]
        var result: Float = 0
        var mycount: Float = 0
        for var i = 0; i < primitivenumber.count; i++ {
            if primitivenumber[i].doubleValue != nil {
                result += Float(primitivenumber[i])!
                mycount += 1
            }

        }
        result = result / mycount
        return result
    }

    func cleanPrimitiveData(inputStr: String) -> String {
        var str = inputStr
        let needle: Character = "s"

        if let idx = inputStr.characters.indexOf(needle) {
            str = str.substringWithRange(Range<String.Index>(start: idx.advancedBy(1),
                end: str.endIndex))

            print("in clean: \(str)")
        }
        return str
    }
}
