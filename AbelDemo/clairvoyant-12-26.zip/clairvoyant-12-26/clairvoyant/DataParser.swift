import Foundation

class DataParser {

    func myparse(myAlldata: NSMutableData) -> (NSNumber?,[String]) {
        var whicheye: NSNumber? = 0
        var primitivenumber: [String] = [String]()
        let ptr = UnsafePointer<UInt8>(myAlldata.bytes)
        let bytes = UnsafeBufferPointer<UInt8>(start: ptr, count: myAlldata.length)
        if bytes.contains(UInt8(0x80)) && bytes.contains(UInt8(0x81)) {
            print("bytes",bytes.count,bytes[21],bytes[22],"mydata=",myAlldata)

            let start = bytes.indexOf(UInt8(0x80)), end = bytes.indexOf(UInt8(0x81))
            print(bytes[start!],bytes[end!])
            if  start <= end  {
                let slice = Array(bytes[start!+1..<end!])
                print("slice=",slice,"length=",slice.count)
                // deal with data length info
                print(slice[0],slice[1])
                var str1 = String(slice[0], radix : 2)
                var str2 = String(slice[1], radix : 2)
                str1 = str1.pad(8)
                str2 = str2.pad(8)
                var newstr = "00"
                print("#1",str1.substringFromIndex(str1.startIndex.advancedBy(1)))
                print("#2",str2.substringFromIndex(str2.startIndex.advancedBy(1)))
                print(str1, str2)
                newstr = newstr + str2.substringFromIndex(str2.startIndex.advancedBy(1))
                newstr = newstr + str1.substringFromIndex(str1.startIndex.advancedBy(1))
                print(newstr.pad(16))
                let length = Int(strtoul(newstr.pad(16),nil,2))
                print("length=", length,"(length % 7 )",(length % 7 ))
                // get additional binary
                let splitIndex: Int =  length + (2) + (7 - length % 7 )
                print("@",slice[2], slice[splitIndex], slice[splitIndex+1], slice[splitIndex+2])
                var addtionalstr = ""
                for var i = Int(splitIndex); i < slice.count; i++ {
                    let tempstr = String(slice[i], radix : 2).pad(8)
                    let index1 = tempstr.startIndex.advancedBy(1)
                    addtionalstr += tempstr.pad(8).substringFromIndex(index1)
                }
                print(addtionalstr)
                var finalStr = ""
                var numbers: [UInt8] = []
                for var j = 2; j < length+2; j++ {
                    //                        print(slice[j])
                    let tempstr =  String(slice[j], radix : 2).pad(8)
                    let index1 = tempstr.startIndex.advancedBy(1)
                    print(tempstr.substringFromIndex(index1),addtionalstr[j-2],"#j=",j)
                    finalStr = finalStr + tempstr.substringFromIndex(index1) + addtionalstr[j-2]
                    let newstr = tempstr.substringFromIndex(index1) + addtionalstr[j-2]
                    let num = UInt8(strtoul(newstr.pad(8),nil,2))
                    print("num=",num)
                    numbers.append(num)

                }
                print(numbers)
                print(finalStr)

                //                    let data = NSData(bytes: finalStr, length: sizeof(String))
                let data = NSData(bytes: numbers, length: length)
                let instanceOfCustomObject: CplusplusMeasureClass = CplusplusMeasureClass()
                var returnObj: ObjectCMeasurement = ObjectCMeasurement()
                returnObj = instanceOfCustomObject.dosomething(data,Int32(length))
                (whicheye,primitivenumber) =  handle_pbdecode(returnObj)
            }

        }


        return (whicheye,primitivenumber)

    }

    func handle_pbdecode(returnObj: ObjectCMeasurement) -> (NSNumber?,[String]) {
        var whicheye: NSNumber? = 0
        var primitivenumber: [String] = [String]()
        if returnObj.sideA == true {
            whicheye = 0
        } else {
            whicheye = 1
        }

        // handle the nanopb decode
        let newptr = UnsafePointer<UInt8>(returnObj.image.bytes)
        let newbytes = UnsafeBufferPointer<UInt8>(start: newptr,
            count: returnObj.image.length)
        print("newbytes count = ",newbytes.count)
        var imagestr = ""
        for var k = 0; k < newbytes.count; k++ {
            let tempstr_a =  String(newbytes[k], radix : 2).pad(8)
            imagestr = imagestr + tempstr_a
        }
        for var l = 0; l < imagestr.characters.count/24; l++ {
            let serial =
            imagestr[24*l..<24*(l+1)]
            let a = serial[0..<8]
            let b = serial[8..<16]
            let c = serial[16..<24]
            let combined_a = b[4..<8] + a
            let combined_b = c + b[0..<4]
            let num_a = UInt(strtoul(combined_a,nil,2))
            let num_b = UInt(strtoul(combined_b,nil,2))

            primitivenumber.append(String(num_a))
            primitivenumber.append(String(num_b))

        }
        print("imagestr count=",imagestr.characters.count)
        return (whicheye,primitivenumber)
    }
}
