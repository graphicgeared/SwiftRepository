#include "measurement.pb.h"
#import "CplusplusMeasureClass.h"
#import "ObjectCMeasurement.h"
#include <fstream>

using namespace std;

@implementation CplusplusMeasureClass

void test(){

}

-(ObjectCMeasurement *) dosomething:(NSData*)buffer :(int)length {
    

    Measurement *measure1 =new Measurement();
    int len1 = (int)[buffer length];
//    NSLog(@"in objec:%d",len1);
    char raw1[len1];
    [buffer getBytes:raw1 length:len1];
    measure1->ParseFromArray(raw1, length);
    char* data1 = (char*)measure1->image().data();
    int t = (int)measure1->image().size();
//    NSLog(@"t is %d",t);

    NSData *dataA = [NSData dataWithBytes: data1   length:t];
    ObjectCMeasurement *returnObj = [[ObjectCMeasurement alloc] init];
    returnObj.sideA = measure1->side_a();
    returnObj.sideB = measure1->side_b();
    returnObj.image = dataA;
    return returnObj;
}



@end
