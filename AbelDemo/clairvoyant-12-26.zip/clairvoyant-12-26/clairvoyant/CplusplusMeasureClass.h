#import <UIKit/UIKit.h>
#import "ObjectCMeasurement.h"

@interface CplusplusMeasureClass : NSObject

-(ObjectCMeasurement *) dosomething:(NSData*)buffer :(int)length;

@end


