//
//  ObjectCMeasurement.h
//  clairvoyant
//
//  Created by 万畅 on 15/12/24.
//  Copyright © 2015年 Luminagic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectCMeasurement : NSObject

@property bool sideA;
@property bool sideB;
@property NSData* image;

@end
