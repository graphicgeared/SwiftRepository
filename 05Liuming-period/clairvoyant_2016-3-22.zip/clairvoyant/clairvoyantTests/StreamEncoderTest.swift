import XCTest
@testable import clairvoyant

class StreamEncoderTest: XCTestCase {
    var encoder: StreamEncoder!

    override func setUp() {
        super.setUp()
        encoder = StreamEncoder()
    }

    func testEmpty() {
        let result = encoder.encode(Measurement()!)
        XCTAssertEqual(result, dataFromByteArray([0x80, 0x00, 0x00, 0x81]))
    }

    func testMessage() {
        let measurement = Measurement()!
        measurement.sideA = true
        let result = encoder.encode(measurement)
        XCTAssertEqual(result, dataFromByteArray([0x80, 0x02, 0x00,
            0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // high bits
            0x20, // low bit
            0x81]))
    }

    func testMessageWithLenth7() {
        let measurement = Measurement()!
        measurement.sideA = true
        measurement.image = dataFromByteArray([0x01, 0x20, 0x00]) // two data points: 1, 2
        let result = encoder.encode(measurement)
        XCTAssertEqual(result, dataFromByteArray([0x80, 0x07, 0x00,
            0x05, 0x01, 0x00, 0x10, 0x00, 0x08, 0x00, // high bits
            0x31, // low bit
            0x81]))
    }

    private func dataFromByteArray(arr: [UInt8]) -> NSData {
        return NSData(bytes: UnsafePointer<UInt8>(arr), length: arr.count)
    }
}
