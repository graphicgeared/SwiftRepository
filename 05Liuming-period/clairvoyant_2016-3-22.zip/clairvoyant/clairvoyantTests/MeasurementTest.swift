import XCTest
@testable import clairvoyant

class MeasurementTest: XCTestCase {
    var measurement: Measurement!

    override func setUp() {
        super.setUp()
        measurement = Measurement()
        measurement.sideA = true
        measurement.sideB = false
        measurement.image = "mock data".dataUsingEncoding(NSUTF8StringEncoding)
    }

    func testGetterSetter() {
        XCTAssertTrue(measurement.sideA!.boolValue)
        XCTAssertFalse(measurement.sideB!.boolValue)
        XCTAssertEqual(measurement.image, "mock data".dataUsingEncoding(NSUTF8StringEncoding))
    }

    func testSerializeParse() {
        let m = Measurement(data: measurement.serializeToData()!)!
        XCTAssertTrue(m.sideA!.boolValue)
        XCTAssertFalse(m.sideB!.boolValue)
        XCTAssertEqual(m.image, "mock data".dataUsingEncoding(NSUTF8StringEncoding))
    }

    func testDefault() {
        let m = Measurement()!
        XCTAssertNil(m.sideA)
        XCTAssertNil(m.sideB)
        XCTAssertNil(m.image)
    }
}
