# clairvoyant
[build status](http://10.3.27.1:8111/project.html?projectId=clairvoyant&branch_clairvoyant=__all_branches__)

## Dev Env
### Xcode 7
Install via AppStore

### swift lint
Install using [Homebrew](http://brew.sh/)

    brew install swiftlint

### arcinist
Arcinist is the command line tool for [Phabricator](http://phabricator.org/)

### Protocol Buffer
Install using Homebrew

    brew install protobuf

### PNChart 
Install using CocoaPods