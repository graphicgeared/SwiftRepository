Supportive file from nanopb-0.3.4

Note that the version of these supportive files should be the same as the
nanopb-generator. Mismatched lib and generator may introduce bug.
