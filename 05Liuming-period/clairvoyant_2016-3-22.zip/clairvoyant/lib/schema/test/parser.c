#include <string.h>
#include "parser.h"

bool parseBool(const char *str, bool *pval) {
    if (strcmp(str, "true") == 0) {
        *pval = true;
        return true;
    }
    if (strcmp(str, "false") == 0) {
        *pval = false;
        return true;
    }
    return false;
}

bool findNonBlank(char **ptr) {
    char *str = *ptr;

    while (*str == ' ') str++;
    if (*str == '\0') {
        return false;
    }

    *ptr = str;
    return true;
}