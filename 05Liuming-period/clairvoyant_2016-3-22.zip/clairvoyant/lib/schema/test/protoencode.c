#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pb.h>
#include <pb_encode.h>
#include "protoencode.h"
#include "parser.h"
#include "notice.pb.h"

#ifdef WIN32
#    include <fcntl.h>
#    include <io.h>
#endif


// Actually allowed max line width will be 2045: It reads at most 2047 chars as 1 extra
// is needed for the trailing zero. But we check that the line is NOT hit the upper limit(2047).
// Within these 2046 chars, the last one is the line-feed \n
#define MAX_LINE 2048

typedef struct _DispatchEntry {
    const char *message;
    size_t decodedSize;
    const pb_field_t *fields;
    bool (*setAttr)(void *message, const char *field, char *value);
} DispatchEntry;

DispatchEntry dispatchEntries[] = {
    {"Measurement", sizeof(cyclops_Measurement), cyclops_Measurement_fields, &setMeasurementAttr},
    // Termination mark. It is ok to omit last three zeros, as the compiler will fill zeros.
    // But still put them all here for clarity.
    {NULL, 0, NULL, NULL}
};

DispatchEntry* findEntry(const char *msgName) {
    DispatchEntry *entry = dispatchEntries;

    for (entry = dispatchEntries; entry->message != NULL; entry++) {
        if (strcmp(entry->message, msgName) == 0) {
            return entry;
        }
    }

    // Unknown message
    return NULL;
}

bool output(pb_ostream_t *stream, const uint8_t *buf, size_t count) {
    return fwrite(buf, 1, count, stdout) == count;
}

bool process(DispatchEntry *entry) {
    void *msgBuf = calloc(entry->decodedSize, 1);
    char lineBuf[MAX_LINE];
    char *delimiter;
    pb_ostream_t pbostream = {&output, NULL, SIZE_MAX, 0 };

    // read attributes from stdin
    while (fgets(lineBuf, MAX_LINE, stdin) != NULL) {
        if (strlen(lineBuf) == MAX_LINE - 1) {
            fprintf(stderr, "Line too long: \n%s\n", lineBuf);
            return false;
        }
        *strchr(lineBuf, '\n') = '\0';
        if ((delimiter = strchr(lineBuf, ':')) == NULL) {
            fprintf(stderr, "No delimiter(:) found:\n%s\n", lineBuf);
            return false;
        }

        // split
        *delimiter++ = '\0';
        findNonBlank(&delimiter);

        // set attribute
        if (entry->setAttr(msgBuf, lineBuf, delimiter) != true) {
            fprintf(stderr, "Failed setting attribute %s\n", lineBuf);
            return false;
        }
    }

#ifdef WIN32
    // set the mode of stdout to binary. This is not necessary for *nix systems as
    // they are using \r as line delimiter which makes text and binary modes identical.
    // https://msdn.microsoft.com/en-us/library/tw4k6df8.aspx
    _setmode(_fileno(stdout), _O_BINARY);
#endif

    // write encoded message to stdout
    if (pb_encode(&pbostream, entry->fields, msgBuf) != true) {
        fprintf(stderr, "Failed to encode the message.\n%s\n", PB_GET_ERROR(&pbostream));
        return false;
    }

    return true;
}

int main(int argc, const char* argv[]) {
    DispatchEntry *entry;

    if (argc != 2) {
        fprintf(stderr,
            "Encoder of messages using nanopb generated code.\n"
            "Usage:\n"
            "    protoencode <message_name>\n"
            "then in STDIN, input field: value\n"
            "one field per line. Close STDIN when finished.\n"
            "Then STDOUT will dump the encoded stream of the message.\n"
            "\n"
            "For example, executing\n"
            "    protoencode Measurement\n"
            "then input,\n"
            "    side_a: true\n"
            "    side_b: false\n"
            "    image: 128 32 99 106 543\n"
        );
        return -1;
    }

    if ((entry = findEntry(argv[1])) == NULL) {
        fprintf(stderr, "Unknown message: %s\n", argv[1]);
        return -1;
    }

    if (!process(entry)) {
        return -1;
    }
    return 0;
}
