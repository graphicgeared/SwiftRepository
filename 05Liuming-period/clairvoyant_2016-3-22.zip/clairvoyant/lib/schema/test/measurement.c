#include <string.h>
#include <stdlib.h>
#include <notice.pb.h>
#include "protoencode.h"
#include "parser.h"

bool setMeasurementAttr(void *message, const char *field, char *value) {
    char *end;
    unsigned short scalar;
    cyclops_Measurement *pmsg = (cyclops_Measurement*)message;

    if (strcmp(field, "side_a") == 0) {
        pmsg->has_side_a = true;
        return parseBool(value, &pmsg->side_a);
    }

    if (strcmp(field, "side_b") == 0) {
        pmsg->has_side_b = true;
        return parseBool(value, &pmsg->side_b);
    }

    if (strcmp(field, "image") == 0) {
        pmsg->has_image = true;
        while (value != NULL && *value != '\0') {
            // find a whitespace (the delimiter) and split it
            end = strchr(value, ' ');
            if (end != NULL) {
                *end = '\0';
            }
            // add one value to the image
            scalar = (unsigned short) atoi(value);
            if (pmsg->image.size % 3 == 0) {
                pmsg->image.bytes[pmsg->image.size++] = (uint8_t) (scalar & 0xFF);
                pmsg->image.bytes[pmsg->image.size++] = (uint8_t) ((scalar >> 8) & 0x0F);
            } else {
                pmsg->image.bytes[pmsg->image.size - 1] |= (uint8_t) ((scalar << 4) & 0xF0);
                pmsg->image.bytes[pmsg->image.size++] = (uint8_t) ((scalar >> 4) & 0xFF);
            }

            // try to move to next value
            if (end != NULL) {
                value = end + 1;
                if (!findNonBlank(&value)) {
                    value = NULL;
                }
            } else {
                value = NULL;
            }
        }
      return true;
    }

    // Unknown field
    return false;
}
