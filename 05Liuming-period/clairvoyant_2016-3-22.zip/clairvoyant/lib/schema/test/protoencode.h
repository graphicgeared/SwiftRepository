#ifndef PROTOENCODE_H
#define PROTOENCODE_H

#include <stdbool.h>

bool setMeasurementAttr(void *message, const char *field, char *value);

#endif //PROTOENCODE_H
