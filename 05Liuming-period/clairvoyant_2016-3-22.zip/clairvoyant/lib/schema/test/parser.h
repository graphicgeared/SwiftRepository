#ifndef CYCLOPS_SCHEMA_UTILS_H
#define CYCLOPS_SCHEMA_UTILS_H


#include <stdbool.h>

bool parseBool(const char *str, bool *pval);

bool findNonBlank(char **ptr);

#endif //CYCLOPS_SCHEMA_UTILS_H
