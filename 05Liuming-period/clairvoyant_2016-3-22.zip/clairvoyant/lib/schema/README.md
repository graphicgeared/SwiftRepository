# Schema of Cyclops

This repository contains the schema(interface) definition for
the communication between device and phone.

## Prerequisite

### scons
Managing compiling and testing tasks.

```
brew install scons
```

### protobuf
Compiling proto files and generating python classes.

```
brew install protobuf
```

### nanopb
Generating C routings from compiled proto, MCU oriented.

```
brew install nanopb-generator
```

### python 3
Test cases scripting

```
brew install python3
```

### pytest
The most popular and probably the most powerful test framework for python.

```
pip3 install pytest
```

## Build and Test
### Build for Desktop & Mobile

### Build for MCU

### Compatibility Test
