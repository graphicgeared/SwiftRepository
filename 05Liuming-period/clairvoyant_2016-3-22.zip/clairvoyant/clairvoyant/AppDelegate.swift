import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    let coreDataStack = CoreDataStack()

    func application(application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let defaults = NSUserDefaults.standardUserDefaults()
        let skipGuidePage = defaults.objectForKey("SkipGuideView")
        print("SkipGuideView=", skipGuidePage)
        if let skipGuidePage = skipGuidePage as? Bool {
            if skipGuidePage == true {
                print("no guide workflow")
                let mainVC = storyboard.instantiateViewControllerWithIdentifier("NavigateVC")
                self.window?.rootViewController = mainVC
            } else {
                let guideViewController =
                storyboard.instantiateViewControllerWithIdentifier("GuideViewController")
                self.window?.rootViewController = guideViewController
            }
        } else {
            //first time there is no history SkipGuideView
            let guideViewController =
                storyboard.instantiateViewControllerWithIdentifier("GuideViewController")
            self.window?.rootViewController = guideViewController
            }

        self.window?.makeKeyAndVisible()
        NotificationOperation.registerNotification()
        return true
    }

    func application(application: UIApplication, shouldRestoreApplicationState coder: NSCoder)
        -> Bool {

        return true
    }

    func application(application: UIApplication, shouldSaveApplicationState coder: NSCoder)
        -> Bool {

        return true
    }

    func applicationDidEnterBackground(application: UIApplication) {
        coreDataStack.saveContext()
    }

    func applicationWillTerminate(application: UIApplication) {
        coreDataStack.saveContext()
    }

    func applicationWillEnterForeground(application: UIApplication) {
        print("in applicationWillEnterForeground")
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
    }
}
