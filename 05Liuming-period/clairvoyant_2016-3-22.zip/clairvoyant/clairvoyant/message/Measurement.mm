#include "notice.pb.h"
#import "messages.h"

@interface Measurement () {
cyclops::Measurement protoMessage;
}

@end

@implementation Measurement

- (instancetype)init {
    if (self = [super init]) {
        return self;
    }

    return nil;
}

- (instancetype)initWithData: (NSData *)data {
    if (self = [super init]) {
        protoMessage.ParseFromArray([data bytes], (int)[data length]);
        return self;
    }

    return nil;
}

- (NSData *)serializeToData {
    std::string buf;
    protoMessage.SerializeToString(&buf);
    return [NSData dataWithBytes:buf.data() length:buf.length()];
}


- (NSNumber *)getSideA {
    if (protoMessage.has_side_a()) {
        return @(protoMessage.side_a());
    }
    return nil;
}

- (void)setSideA: (NSNumber *)value {
    if (value == nil) {
        protoMessage.clear_side_a();
        return;
    }
    protoMessage.set_side_a([value boolValue]);
}

- (NSNumber *)getSideB {
    if (protoMessage.has_side_b()) {
        return @(protoMessage.side_b());
    }
    return nil;
}

- (void)setSideB: (NSNumber *)value {
    if (value == nil) {
        protoMessage.clear_side_b();
        return;
    }
    protoMessage.set_side_b([value boolValue]);
}

- (NSData *)getImage {
    if (protoMessage.has_image()) {
        return [NSData dataWithBytes:protoMessage.image().data() length:protoMessage.image().length()];
    }
    return nil;
}

- (void)setImage:(NSData *)image {
    if (image == nil) {
        protoMessage.clear_image();
        return;
    }
    protoMessage.set_image([image bytes], [image length]);
}

@end
