import Foundation

class StreamDecoder {
    static let BEGINNING: UInt8 = 0x80
    static let ENDING: UInt8 = 0x81

    private enum State {
        case Beginning
        case Length
        case LowBit
        case HighBits
        case Ending
        case Error
    }
    private var state = State.Beginning
    private var currentPos = 0
    private var messageLength: Int?
    private var rawData: [UInt8] = []

    // TODO: Should be Notice -> (). To support current firmware, use Measurement
    var onMessageReceived: Measurement -> () = {_ in }
    var onIllFormedData: () -> () = {}

    func feed(data: NSData) {
        for byte in UnsafeBufferPointer<UInt8>(
            start: UnsafePointer(data.bytes), count: data.length) {

            feed(byte)
        }
    }

    private func feed(byte: UInt8) {
        if state == .Error && byte != StreamDecoder.BEGINNING {
            return
        }
        switch byte {
        case StreamDecoder.BEGINNING:
            // epecting the length
            currentPos = 0
            messageLength = nil
            rawData = []
            state = .Length
        case StreamDecoder.ENDING:
            if currentPos == messageLength {
                deserialize()
            } else {
                fireIllFormedDataEvent()
            }
            // expecting mark of beginning
            state = .Beginning
        case 0 ..< 0x80:
            feedDataByte(byte)
        default:
            fireIllFormedDataEvent()
        }
    }

    private func feedDataByte(byte: UInt8) {
        switch state {
        case .Length:
            if currentPos == 0 {
                rawData.append(byte)
                currentPos += 1
            } else {
                // got length
                let length = Int(byte) << 7 + Int(rawData[0])
                // round to 7
                messageLength = length == 0 ? 0 : ((length - 1) / 7 + 1) * 7
                // expecting low bits of the data
                currentPos = 0
                rawData = []
                state = .HighBits
            }
        case .HighBits:
            currentPos += 1
            rawData.append(byte << 1)
            if currentPos == messageLength {
                // expecting high bit of the data
                currentPos = 0
                state = .LowBit
            }
        case .LowBit:
            for i in 0 ..< 7 {
                rawData[currentPos] ^= (byte >> UInt8(6 - i)) & 1
                currentPos += 1
            }
            if currentPos == messageLength {
                // expecting mark of ending
                state = .Ending
            }
        case .Error: break
        default:
            fireIllFormedDataEvent()
        }
    }

    func fireIllFormedDataEvent() {
        onIllFormedData()
        state = .Error
    }

    func deserialize() {
        let data = NSData(bytes: UnsafePointer<UInt8>(rawData), length: messageLength!)
        let message = Measurement(data: data)
        if let msg = message {
            onMessageReceived(msg)
        }
    }
}
