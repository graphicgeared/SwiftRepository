#import <Foundation/Foundation.h>

@interface Measurement : NSObject

- (nullable instancetype)init;
- (nullable instancetype)initWithData: (nonnull NSData *)data;
- (nullable NSData *)serializeToData;

@property(nullable, getter=getSideA, setter=setSideA:) NSNumber * sideA;

@property(nullable, getter=getSideB, setter=setSideB:) NSNumber * sideB;

// TODO: consider to use array of short integer instead, especially data processing will be
// written in c++
@property(nullable, getter=getImage, setter=setImage:) NSData *image;
@end