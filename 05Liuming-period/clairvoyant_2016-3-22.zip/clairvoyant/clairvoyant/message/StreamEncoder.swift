import Foundation

class StreamEncoder {
    // TODO: Use Instruction instead
    func encode(message: Measurement) -> NSData {
        let raw = message.serializeToData()!
        let numSection = raw.length == 0 ? 0 : (raw.length - 1) / 7 + 1
        let length = numSection * 8 + 4
        var offsetLowBit = 3 + numSection * 7
        var buf = [UInt8](count: length, repeatedValue: 0)
        buf[0] = 0x80
        buf[1] = UInt8(raw.length & 0x7F)
        buf[2] = UInt8(raw.length >> 7)

        var rawbuf = UnsafePointer<UInt8>(raw.bytes)
        var bit: UInt8 = 7
        for i in 0..<raw.length {
            let byte = rawbuf.memory
            rawbuf = rawbuf.successor()
            buf[3 + i] = byte >> 1
            --bit
            buf[offsetLowBit] ^= (byte & 1) << bit
            if bit == 0 {
                ++offsetLowBit
                bit = 7
            }
        }
        buf[length - 1] = 0x81

        return NSData(bytes: UnsafePointer<UInt8>(buf), length: length)
    }
}
