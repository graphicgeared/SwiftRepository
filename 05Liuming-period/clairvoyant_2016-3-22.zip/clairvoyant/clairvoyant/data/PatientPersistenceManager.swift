import CoreData

class PatientPersistenceManager: NSObject {

    class func create(name: String, birthday: NSDate, imageData: NSData) {
        let patient = NSEntityDescription.insertNewObjectForEntityForName("Patient",
            inManagedObjectContext: CoreDataStack.sharedInstance.context) as? Patient
        if let patient = patient {
            patient.name = name
            patient.birthday = birthday
            patient.imageData = imageData
            do {
                try CoreDataStack.sharedInstance.context.save()
                CoreDataStack.sharedInstance.loadPatientData()
            } catch let unknownError {
                print("save patient error \(unknownError) is an unknown error.")
            }
        }
    }

    class func edit(name: String, birthday: NSDate, imageData: NSData, patientIndex: Int) {
        print("in edit save")
        CoreDataStack.sharedInstance.loadPatientData()
        var patients = CoreDataStack.sharedInstance.patients
        patients[patientIndex].name = name
        patients[patientIndex].birthday = birthday
        patients[patientIndex].imageData = imageData
        do {
            try CoreDataStack.sharedInstance.context.save()
            CoreDataStack.sharedInstance.loadPatientData()
        } catch let unknownError {
            print("save patient error \(unknownError) is an unknown error.")
        }
    }

    class func get(patientIndex: Int) -> Patient {
        CoreDataStack.sharedInstance.loadPatientData()
        return CoreDataStack.sharedInstance.patients[patientIndex]
    }

}
