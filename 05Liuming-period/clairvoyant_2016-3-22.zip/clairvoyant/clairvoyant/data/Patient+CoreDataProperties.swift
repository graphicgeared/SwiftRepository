import Foundation
import CoreData

extension Patient {

    @NSManaged var birthday: NSDate?
    @NSManaged var name: String?
    @NSManaged var sex: String?
    @NSManaged var imageData: NSData?
    @NSManaged var sights: NSOrderedSet?

}
