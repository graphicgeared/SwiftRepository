import Foundation
import CoreData

@objc(Patient)
class Patient: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
