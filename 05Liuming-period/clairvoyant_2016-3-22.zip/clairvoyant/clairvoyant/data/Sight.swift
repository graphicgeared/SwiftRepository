import Foundation
import CoreData

@objc(Sight)
class Sight: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
