import UIKit
import CoreBluetooth

class PeripheralTableViewCell: UITableViewCell {


    @IBOutlet weak var nameLabel: UILabel!

    @IBOutlet weak var uuidLabel: UILabel!

    @IBOutlet weak var rssiLabel: UILabel!

    @IBOutlet weak var connectableLabel: UILabel!

    @IBOutlet weak var otherLabel: UILabel!

    func setupWithPeripheral(peripheral: Peripheral) {
        nameLabel.text = peripheral.name
        uuidLabel.text = peripheral.uuid
        rssiLabel.text = peripheral.rssi
        connectableLabel.text = peripheral.connectable
    }
}
