import UIKit
import CoreData

protocol PatientViewControllerDelegate {
    func patientViewControllerResponse(name: String, birthday: NSDate, imageData: NSData)
}

class PatientViewController: UIViewController, UITextFieldDelegate,
UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var delegate: PatientViewControllerDelegate?
    @IBOutlet weak var nameTextField: UITextField!

    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var datePicker: UIDatePicker!

    var patientName: String = ""
    var patientBirthday: NSDate?
    var imageData: NSData? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        nameTextField.text = patientName
        datePicker.datePickerMode = UIDatePickerMode.Date
        guard let converteddate = patientBirthday else {
            return
        }
        datePicker.date = converteddate
        photoImageView.image = UIImage(data: imageData!)
    }

    @IBAction func cancel(sender: UIBarButtonItem) {
        navigationController!.popViewControllerAnimated(true)
    }

    @IBAction func save(sender: UIBarButtonItem) {
        parepare()
        self.delegate?.patientViewControllerResponse(patientName, birthday: patientBirthday!,
            imageData: imageData!)
        navigationController!.popViewControllerAnimated(true)
    }

    func parepare() {
        patientName = nameTextField.text ?? ""
        let photo = photoImageView.image
        imageData = UIImageJPEGRepresentation(photo!, 1)
        patientBirthday = datePicker.date
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // hide keyboard
        textField.resignFirstResponder()
        return true
    }

    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        // Dismiss the picker if the user canceled.
        dismissViewControllerAnimated(true, completion: nil)
    }

    func imagePickerController(picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String: AnyObject]) {

        let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        // Set photoImageView to display the selected image.
        photoImageView.image = selectedImage
        // Dismiss the picker.
        dismissViewControllerAnimated(true, completion: nil)
    }

    @IBAction func selectImageFromPhotoLibrary(sender: UITapGestureRecognizer) {
        print("in select picture")
        // hide the keyboard
        nameTextField.resignFirstResponder()
        let imagePickerController = UIImagePickerController()
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .PhotoLibrary
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        presentViewController(imagePickerController, animated: true, completion: nil)
    }

}
