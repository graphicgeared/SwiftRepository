import UIKit

class MeasureSightViewController: UIViewController {

    @IBOutlet weak var showEye: UILabel!
    @IBOutlet weak var saveDataButton: UIButton!
    @IBOutlet weak var chosenLabel: UILabel!
    @IBOutlet weak var userPicker: UIPickerView!
}
