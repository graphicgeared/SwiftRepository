import UIKit
import Foundation
import CoreBluetooth


class PeripheralViewController: UIViewController, CBPeripheralDelegate, UITableViewDataSource {
    var dataStr = ""

    @IBOutlet weak var nameLabel: UILabel!

    @IBOutlet weak var uuidLabel: UILabel!

    @IBOutlet weak var rssiLabel: UILabel!


    @IBOutlet weak var tableView: UITableView!

    var peripheral: CBPeripheral!

    override func viewDidLoad() {
        tableView.dataSource = self
    }

    override func viewDidAppear(animated: Bool) {

        print("Peripheral: \(peripheral)")

        nameLabel.text = peripheral.name ?? "No Name"
        uuidLabel.text = peripheral.identifier.UUIDString
        rssiLabel.text = "No Name"

        peripheral.delegate = self
        peripheral.readRSSI()
        peripheral.discoverServices(nil)
    }

    func peripheral(peripheral: CBPeripheral, didDiscoverServices error: NSError?) {
        print("Did discover services.")
        if let error = error {
            print(error)
        } else {
            print("\(peripheral.services)")
            tableView.reloadData()
        }

        print("## find service= \(peripheral.services?.count) # \(peripheral.services)")
        for service in peripheral.services! {
            if service.UUID.description == "FFE0" {
                peripheral.discoverCharacteristics(nil, forService: (service as CBService))
            }
        }
    }

    // to handle characteristic discovery, like say, for the battery of a FitBit Flex.
    func peripheral(peripheral: CBPeripheral,
        didDiscoverCharacteristicsForService service: CBService, error: NSError?) {

        let characteristic = service.characteristics![0] as CBCharacteristic
        print("@@@@\n @@@ \(characteristic)")
        peripheral.readValueForCharacteristic(characteristic)
        peripheral.setNotifyValue(true, forCharacteristic: characteristic)
    }

    // you want to recieve updates for a characteristic, like say, the battery for a FitBit Flex.
    func peripheral(peripheral: CBPeripheral,
        didUpdateValueForCharacteristic characteristic: CBCharacteristic, error: NSError?) {

        if let error = error {
            print("Failed to updated value for characteristic with error: \(error)")
        } else {
            if characteristic.value != nil {
                if let convertedString =  NSString(data: characteristic.value!,
                    encoding: NSUTF8StringEncoding) as? String {

                    dataStr = dataStr + convertedString
                    print("### \(dataStr)")
                    NotificationOperation.sendNotification("Let's measure")
                }
            }
        }
    }

    // swiftlint:disable variable_name
    func peripheral(peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: NSError?) {
        print("Did update RSSI.")
        if let error = error {
            print("Error getting RSSI: \(error)")
            rssiLabel.text = "Error getting RSSI."
        } else {
            rssiLabel.text = "\(RSSI)"
        }
    }

    func tableView(tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCellWithIdentifier("ServiceCell",
            forIndexPath: indexPath)
        let service = peripheral.services![indexPath.row] as CBService

        print("Service UUID Desc: \(service.UUID.description)")
        cell.textLabel?.text = service.UUID.description

        return cell
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peripheral.services?.count ?? 0
    }
}
