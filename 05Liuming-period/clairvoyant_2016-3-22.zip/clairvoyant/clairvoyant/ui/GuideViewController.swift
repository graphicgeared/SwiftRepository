import UIKit

class GuideViewController: UIViewController, UIScrollViewDelegate {

    private let numOfPages = 3
    var skipFlag = false
    let defaults = NSUserDefaults.standardUserDefaults()
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var scrollView: UIScrollView!

    @IBAction func buttonTouched(sender: UIButton) {
        defaults.setBool(skipFlag, forKey: "SkipGuideView")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let frame = self.view.bounds
        scrollView.frame = frame
        scrollView.scrollsToTop = false
        scrollView.contentOffset = CGPointZero
        scrollView.contentSize = CGSize(width: frame.size.width * CGFloat(numOfPages),
            height: frame.size.height)
        scrollView.delegate = self
        for index  in 0..<numOfPages {
            let imageView = UIImageView(image: UIImage(named: "GuideImage\(index + 1)"))
            imageView.frame = CGRect(x: frame.size.width * CGFloat(index), y: 0,
                width: frame.size.width, height: frame.size.height)
            scrollView.addSubview(imageView)
        }
        self.view.insertSubview(scrollView, atIndex: 0)
    }

    override func prefersStatusBarHidden() -> Bool {
        return true
    }

    func scrollViewDidScroll(scrollView: UIScrollView) {
        let offset = scrollView.contentOffset
        let current = Int(offset.x / view.bounds.width)
        pageControl.currentPage = current
        if current != numOfPages-1 {
            startButton.setTitle("跳过", forState: .Normal)
            skipFlag = true
        } else {
            startButton.setTitle("开始体验", forState: .Normal)
            skipFlag = false
        }
    }
}
